package com.bubblerift.game;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebSettings; import android.webkit.WebViewClient;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState){ super.onCreate(savedInstanceState); WebView w=new WebView(this); w.setWebViewClient(new WebViewClient()); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); w.setBackgroundColor(0xff101827); setContentView(w); w.loadUrl("file:///android_asset/index.html"); }
 @Override public void onBackPressed(){super.onBackPressed();}
}
