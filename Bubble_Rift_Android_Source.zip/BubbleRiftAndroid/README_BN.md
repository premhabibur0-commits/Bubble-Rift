# Bubble Rift Android Build

এই প্রজেক্টে Bubble Rift HTML game-কে Android WebView অ্যাপে প্যাক করার Gradle project এবং GitHub Actions APK build workflow আছে।

## ফোন থেকে APK বানানোর উপায়
1. ZIP GitHub-এ নতুন repository হিসেবে আপলোড করুন।
2. Repository-এর Actions tab-এ গিয়ে `Build Bubble Rift APK` workflow চালু/দেখুন।
3. Build সফল হলে workflow run-এর Artifacts থেকে `Bubble-Rift-debug-apk` ডাউনলোড করুন।
4. APK ফোনে ইনস্টল করুন (প্রয়োজনে Android-এ install unknown apps permission দিন)।

এটি debug APK; Play Store release-এর আগে device testing, signing, privacy/policy review এবং reward/wallet-এর server-side ব্যবস্থা লাগবে।

## GitHub Actions workflow
এই project-এর `.github/workflows/android.yml` workflow `workflow_dispatch` দিয়ে হাতে চালানো যায়। GitHub repository-তে পুরো project folder structure বজায় রেখে upload করলে সরাসরি build হবে। বিকল্পভাবে ZIP-টি repository root-এ `Bubble_Rift_Android_Source.zip` নামে রাখুন এবং workflow ফাইলটি repository-তে `.github/workflows/android.yml` path-এ রাখুন; workflow ZIP extract করে APK build করবে।
